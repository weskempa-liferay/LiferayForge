// Header functionality
(function() {
    'use strict';
    
    const headerElement = fragmentElement.querySelector('.whittier-header');
    
    // Add scroll behavior for sticky header (optional)
    if (headerElement) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                headerElement.classList.add('scrolled');
            } else {
                headerElement.classList.remove('scrolled');
            }
        });
    }
    
    // Accessibility improvements
    const utilityLinks = fragmentElement.querySelectorAll('.utility-link');
    utilityLinks.forEach(link => {
        link.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    });
})();