// Simple banner functionality for Liferay
(function() {
    'use strict';

    const banner = document.querySelector('.whittier-banner');
    const ctaButton = document.querySelector('.banner-cta');
    
    // Basic CTA functionality
    if (ctaButton) {
        ctaButton.setAttribute('role', 'button');
    }
})();