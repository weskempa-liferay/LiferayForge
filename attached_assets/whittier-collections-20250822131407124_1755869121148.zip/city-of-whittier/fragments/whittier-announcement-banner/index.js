// Simple announcement banner for Liferay - scoped to current fragment
(function() {
    'use strict';
    
    // Find the current fragment container
    const currentScript = document.currentScript || document.scripts[document.scripts.length - 1];
    const banner = currentScript.closest('.whittier-announcement-banner') || 
                  currentScript.parentElement.closest('.whittier-announcement-banner');
    
    if (banner) {
        const closeButton = banner.querySelector('.announcement-close');
        
        if (closeButton) {
            closeButton.addEventListener('click', function() {
                banner.style.display = 'none';
            });
        }
    }
})();