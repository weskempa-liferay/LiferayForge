// Simple section heading for Liferay
(function() {
    'use strict';

    const heading = document.querySelector('.whittier-section-heading');
    
    if (heading) {
        const title = heading.querySelector('.section-title');
        const description = heading.querySelector('.section-description');
        
        if (title && description) {
            title.setAttribute('aria-describedby', description.id || 'section-desc');
        }
    }
})();