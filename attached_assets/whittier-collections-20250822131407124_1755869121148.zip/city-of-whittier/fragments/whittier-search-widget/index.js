// Search widget styling container - no additional JavaScript needed for Liferay widget
(function() {
    'use strict';
    
    // This fragment provides styling container for Liferay Search Bar widget
    // All functionality is handled by the native Liferay widget
    
    // Optional: Add any custom enhancements here if needed
})();