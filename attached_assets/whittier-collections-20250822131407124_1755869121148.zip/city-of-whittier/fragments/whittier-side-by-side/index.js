// Simple side-by-side layout for Liferay
(function() {
    'use strict';

    const section = document.querySelector('.whittier-side-by-side');
    
    if (section) {
        const contentColumn = section.querySelector('.content-column');
        const imageColumn = section.querySelector('.image-column');
        
        if (contentColumn && imageColumn) {
            contentColumn.setAttribute('role', 'region');
            imageColumn.setAttribute('role', 'img');
        }
    }
})();