// Simple page navigation for Liferay
(function() {
    'use strict';

    const container = document.querySelector('.whittier-page-navigation');
    
    if (container) {
        const navLinks = container.querySelectorAll('.nav-link');
        
        navLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                // Remove active class from all items
                container.querySelectorAll('.nav-item').forEach(function(item) {
                    item.classList.remove('active');
                });
                
                // Add active class to clicked item
                const parentItem = link.closest('.nav-item');
                if (parentItem) {
                    parentItem.classList.add('active');
                    link.setAttribute('aria-current', 'page');
                }
            });
        });
    }
})();