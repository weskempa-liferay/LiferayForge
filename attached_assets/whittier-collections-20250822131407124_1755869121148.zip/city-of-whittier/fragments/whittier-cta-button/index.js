// CTA button - no content modification to preserve editable fields
(function() {
    'use strict';
    
    // This fragment provides styling only
    // All accessibility attributes are in the HTML
    // No JavaScript modification to preserve Liferay editable content
})();