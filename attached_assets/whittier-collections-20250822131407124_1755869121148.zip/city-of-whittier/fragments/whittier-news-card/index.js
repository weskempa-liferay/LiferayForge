// Simple news card functionality for Liferay
(function() {
    'use strict';

    const newsCard = document.querySelector('.whittier-news-card .news-card');
    
    if (newsCard) {
        newsCard.setAttribute('role', 'article');
        const title = newsCard.querySelector('.news-title');
        if (title) {
            newsCard.setAttribute('aria-label', 'News article: ' + title.textContent);
        }
    }
})();