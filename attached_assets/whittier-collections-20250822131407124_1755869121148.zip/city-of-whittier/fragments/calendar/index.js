(() => {
  const container = fragmentElement.querySelector(".calendar-root");

  const collection = JSON.parse(
    fragmentElement.querySelector(`#${fragmentEntryLinkNamespace}fc-events`)
      .textContent
  );

  const MOCK_EVENTS = [
    {
      title: "Uptown Whittier Farmers Market",
      start: "2025-08-01T08:00:00",
      end: "2025-08-01T13:00:00",
      location: "Uptown Whittier Plaza",
      allDay: false,
      backgroundColor: "#2E7D32",
      url: "/",
    },
    {
      title: "Uptown Whittier Farmers Market",
      start: "2025-08-08T08:00:00",
      end: "2025-08-08T13:00:00",
      location: "Uptown Whittier Plaza",
      allDay: false,
      backgroundColor: "#2E7D32",
      url: "/",
    },
    {
      title: "Uptown Whittier Farmers Market",
      start: "2025-08-15T08:00:00",
      end: "2025-08-15T13:00:00",
      location: "Uptown Whittier Plaza",
      allDay: false,
      backgroundColor: "#2E7D32",
      url: "/",
    },
    {
      title: "Uptown Whittier Farmers Market",
      start: "2025-08-22T08:00:00",
      end: "2025-08-22T13:00:00",
      location: "Uptown Whittier Plaza",
      allDay: false,
      backgroundColor: "#2E7D32",
      url: "/",
    },
    {
      title: "Uptown Whittier Farmers Market",
      start: "2025-08-29T08:00:00",
      end: "2025-08-29T13:00:00",
      location: "Uptown Whittier Plaza",
      allDay: false,
      backgroundColor: "#2E7D32",
    },

    {
      title: "Concerts in the Park - City Beat Band & the Main Street Horns",
      start: "2025-08-04T19:00:00",
      end: "2025-08-04T20:30:00",
      location: "Central Park",
      backgroundColor: "#1565C0",
      url: "/",
    },
    {
      title: "Concerts in the Park - Bruno & the Hooligans",
      start: "2025-08-11T19:00:00",
      end: "2025-08-11T20:30:00",
      location: "Central Park",
      backgroundColor: "#1565C0",
      url: "/",
    },
    {
      title: "Concerts in the Park - The Dreamboats",
      start: "2025-08-18T19:00:00",
      end: "2025-08-18T20:30:00",
      location: "Central Park",
      backgroundColor: "#1565C0",
      url: "/",
    },
    {
      title: "Concerts in the Park - Electric Vinyl",
      start: "2025-08-25T19:00:00",
      end: "2025-08-25T20:30:00",
      location: "Central Park",
      backgroundColor: "#1565C0",
      url: "/",
    },

    {
      title: "City Council Meeting",
      start: "2025-08-12T18:00:00",
      end: "2025-08-12T21:00:00",
      location: "City Hall Council Chambers",
      backgroundColor: "#37474F",
      url: "/",
    },
    {
      title: "City Council Meeting",
      start: "2025-08-26T18:00:00",
      end: "2025-08-26T21:00:00",
      location: "City Hall Council Chambers",
      backgroundColor: "#37474F",
      url: "/",
    },

    {
      title: "Board of Library Trustees Meeting",
      start: "2025-08-25T18:30:00",
      end: "2025-08-25T19:30:00",
      location: "Central Library",
      backgroundColor: "#6A1B9A",
      url: "/",
    },
    {
      title: "Cultural Arts Commission",
      start: "2025-08-25T18:00:00",
      end: "2025-08-25T19:30:00",
      location: "City Hall",
      backgroundColor: "#8E24AA",
      url: "/",
    },
    {
      title: "Art in Public Places Advisory Committee",
      start: "2025-08-27T16:30:00",
      end: "2025-08-27T17:30:00",
      location: "City Hall",
      backgroundColor: "#8E24AA",
      url: "/",
    },
    {
      title: "Teen Advisory Board (TAB) - Central Library",
      start: "2025-08-27T17:30:00",
      end: "2025-08-27T18:30:00",
      location: "Central Library",
      backgroundColor: "#AD1457",
      url: "/",
    },
    {
      title: "Start of Students Run Whittier",
      start: "2025-08-25",

      end: "2025-08-28T18:00:00",
      backgroundColor: "#00897B",
      url: "/",
    },

    {
      title: "LEGO Club - Central Library",
      start: "2025-08-11T15:30:00",
      end: "2025-08-11T16:30:00",
      location: "Central Library",
      backgroundColor: "#F4511E",
      url: "/",
    },
    {
      title: "LEGO Club - Whittwood Branch",
      start: "2025-08-26T15:00:00",
      end: "2025-08-26T16:00:00",
      location: "Whittwood Branch",
      backgroundColor: "#F4511E",
      url: "/",
    },
    {
      title: "Coding Camp - Central MakerSpace",
      start: "2025-08-26T15:30:00",
      end: "2025-08-26T17:00:00",
      location: "Central Library MakerSpace",
      backgroundColor: "#039BE5",
      url: "/",
    },
    {
      title: "Game On! - Whittwood Branch",
      start: "2025-08-26T18:00:00",
      end: "2025-08-26T19:30:00",
      location: "Whittwood Branch",
      backgroundColor: "#039BE5",
      url: "/",
    },
    {
      title: "Teen Book Club - Central",
      start: "2025-08-12T17:30:00",
      end: "2025-08-12T18:30:00",
      location: "Central Library",
      backgroundColor: "#AD1457",
      url: "/",
    },
    {
      title: "Read to a Dog - Central Library",
      start: "2025-08-12T18:00:00",
      end: "2025-08-12T19:00:00",
      location: "Central Library",
      backgroundColor: "#5D4037",
      url: "/",
    },
    {
      title: "A to Z Database Preview - Central",
      start: "2025-08-13T18:00:00",
      end: "2025-08-13T19:00:00",
      location: "Central Library",
      backgroundColor: "#5E35B1",
      url: "/",
    },

    {
      title: "Toddler Storytime",
      start: "2025-08-05T10:30:00",
      end: "2025-08-05T11:00:00",
      location: "Central Library",
      backgroundColor: "#EF6C00",
      url: "/",
    },
    {
      title: "Toddler Storytime",
      start: "2025-08-07T10:30:00",
      end: "2025-08-07T11:00:00",
      location: "Central Library",
      backgroundColor: "#EF6C00",
      url: "/",
    },
    {
      title: "Toddler Storytime",
      start: "2025-08-12T10:30:00",
      end: "2025-08-12T11:00:00",
      location: "Central Library",
      backgroundColor: "#EF6C00",
      url: "/",
    },
    {
      title: "Toddler Storytime",
      start: "2025-08-14",
      allDay: true,
      location: "Central Library",
      backgroundColor: "#EF6C00",
      url: "/",
    },
    {
      title: "Toddler Storytime",
      start: "2025-08-19T10:30:00",
      end: "2025-08-19T11:00:00",
      location: "Central Library",
      backgroundColor: "#EF6C00",
      url: "/",
    },
    {
      title: "Toddler Storytime",
      start: "2025-08-21T10:30:00",
      end: "2025-08-21T11:00:00",
      location: "Central Library",
      backgroundColor: "#EF6C00",
      url: "/",
    },
    {
      title: "Toddler Storytime",
      start: "2025-08-26T10:30:00",
      end: "2025-08-26T11:00:00",
      location: "Central Library",
      backgroundColor: "#EF6C00",
      url: "/",
    },
    {
      title: "Toddler Storytime",
      start: "2025-08-28T10:30:00",
      end: "2025-08-28T11:00:00",
      location: "Central Library",
      backgroundColor: "#EF6C00",
      url: "/",
    },

    {
      title: "Senior Center: Line Dancing",
      start: "2025-08-06T09:00:00",
      end: "2025-08-06T10:00:00",
      location: "Whittier Senior Center",
      backgroundColor: "#6D4C41",
      url: "/",
    },
    {
      title: "Senior Center: Line Dancing",
      start: "2025-08-13T09:00:00",
      end: "2025-08-13T10:00:00",
      location: "Whittier Senior Center",
      backgroundColor: "#6D4C41",
      url: "/",
    },
    {
      title: "Senior Center: Line Dancing",
      start: "2025-08-20T09:00:00",
      end: "2025-08-20T10:00:00",
      location: "Whittier Senior Center",
      backgroundColor: "#6D4C41",
      url: "/",
    },
    {
      title: "Senior Center: Line Dancing",
      start: "2025-08-27T09:00:00",
      end: "2025-08-27T10:00:00",
      location: "Whittier Senior Center",
      backgroundColor: "#6D4C41",
      url: "/",
    },
    {
      title: "Family Swim Night",
      start: "2025-08-09T18:00:00",
      end: "2025-08-09T20:00:00",
      location: "Palm Park Pool",
      backgroundColor: "#00ACC1",
      url: "/",
    },
    {
      title: "Family Swim Night",
      start: "2025-08-23T18:00:00",
      end: "2025-08-23T20:00:00",
      location: "Palm Park Pool",
      backgroundColor: "#00ACC1",
      url: "/",
    },
    {
      title: "Community Cleanup - Uptown",
      start: "2025-08-16T09:00:00",
      end: "2025-08-16T11:00:00",
      location: "Uptown District",
      backgroundColor: "#558B2F",
      url: "/",
    },
  ];

  const events = configuration.useCollection ? collection : MOCK_EVENTS;

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const existing = document.querySelector(`script[src="${src}"]`);
      if (existing) {
        if (window.FullCalendar) return resolve();
        existing.addEventListener("load", resolve);
        existing.addEventListener("error", reject);
        return;
      }
      const s = document.createElement("script");
      s.src = src;
      s.async = true;
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  async function boot() {
    try {
      await loadScript(
        "https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"
      );

      const calendar = new FullCalendar.Calendar(container, {
        height: "auto",
        initialView: "dayGridMonth",
        headerToolbar: {
          left: "prev,next today",
          center: "title",
          right: "dayGridMonth,timeGridWeek,timeGridDay,listWeek",
        },
        navLinks: true,
        nowIndicator: true,
        events: events,
      });

      calendar.render();
    } catch (err) {
      console.error("[FullCalendar] Error initializing:", err);
      container.innerHTML =
        '<div style="color:#b00">Error loading calendar.</div>';
    }
  }

  boot();
})();