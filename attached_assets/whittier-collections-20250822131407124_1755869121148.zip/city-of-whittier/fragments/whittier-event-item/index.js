// Simple event item functionality for Liferay
(function() {
    'use strict';

    const eventItem = document.querySelector('.whittier-event-item .event-item');
    
    if (eventItem) {
        eventItem.setAttribute('role', 'article');
        const title = eventItem.querySelector('.event-title');
        if (title) {
            eventItem.setAttribute('aria-label', 'Event: ' + title.textContent);
        }
    }
})();