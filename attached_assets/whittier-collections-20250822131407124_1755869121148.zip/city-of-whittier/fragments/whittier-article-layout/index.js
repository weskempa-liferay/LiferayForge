// Simple article layout for Liferay
(function() {
    'use strict';

    const article = document.querySelector('.whittier-article-layout');
    
    if (article) {
        const shareButtons = article.querySelectorAll('.share-button');
        
        shareButtons.forEach(function(button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                // Add share functionality hook
            });
        });
    }
})();