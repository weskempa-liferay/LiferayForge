// Mobile menu toggle functionality - scoped to current fragment
(function() {
    'use strict';
    
    function initNavigation() {
        // Find all navigation containers (support multiple instances)
        const navigationContainers = document.querySelectorAll('.whittier-navigation');
        
        navigationContainers.forEach(function(navigationContainer) {
            if (navigationContainer.hasAttribute('data-nav-initialized')) return;
            navigationContainer.setAttribute('data-nav-initialized', 'true');
        
            const toggleBtn = navigationContainer.querySelector('.mobile-menu-toggle');
            const navMenu = navigationContainer.querySelector('.navigation-widget-zone');
            
            if (toggleBtn && navMenu) {
                // Generate unique ID for this instance
                const instanceId = 'nav-' + Math.random().toString(36).substr(2, 9);
                navigationContainer.setAttribute('data-nav-id', instanceId);
            
                toggleBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const isExpanded = toggleBtn.getAttribute('aria-expanded') === 'true';
                    
                    // Toggle menu visibility
                    navMenu.classList.toggle('mobile-active');
                    
                    // Update ARIA attributes
                    toggleBtn.setAttribute('aria-expanded', !isExpanded);
                    
                    // Toggle icon
                    const icon = toggleBtn.querySelector('i');
                    if (icon) {
                        if (isExpanded) {
                            icon.className = 'fas fa-bars';
                        } else {
                            icon.className = 'fas fa-times';
                        }
                    }
                });
            
                // Close menu when clicking outside (scoped to this instance)
                document.addEventListener('click', function(event) {
                    if (!toggleBtn.contains(event.target) && !navMenu.contains(event.target)) {
                        navMenu.classList.remove('mobile-active');
                        toggleBtn.setAttribute('aria-expanded', 'false');
                        const icon = toggleBtn.querySelector('i');
                        if (icon) {
                            icon.className = 'fas fa-bars';
                        }
                    }
                });
                
                // Close menu on window resize if mobile menu is hidden
                window.addEventListener('resize', function() {
                    if (window.innerWidth > 991) {
                        navMenu.classList.remove('mobile-active');
                        toggleBtn.setAttribute('aria-expanded', 'false');
                        const icon = toggleBtn.querySelector('i');
                        if (icon) {
                            icon.className = 'fas fa-bars';
                        }
                    }
                });
            }
        });
    }
    
    // Initialize immediately or wait for DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initNavigation);
    } else {
        initNavigation();
    }
})();