// Simple content card for Liferay
(function() {
    'use strict';

    const card = document.querySelector('.whittier-content-card');
    
    if (card) {
        const container = card.querySelector('.card-container');
        const link = card.querySelector('.card-link');
        
        if (container) {
            container.setAttribute('role', 'article');
        }
    }
})();