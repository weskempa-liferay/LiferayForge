// Basic hero functionality for Liferay
(function() {
    'use strict';
    
    const heroSection = document.querySelector('.whittier-hero');
    const heroImage = document.querySelector('.hero-image');
    
    // Simple image loading
    if (heroImage) {
        heroImage.classList.add('loaded');
    }
})();